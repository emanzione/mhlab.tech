---
title: "Support and Discussions"
date: 2017-11-01T18:10:14+01:00

tags: ['Discord', 'Support']
author: "Emanuele Manzione"
noSummary: true

resizeImages: true
---
Hey there!

If you want to chat with me and other guys, feel free to join our Discord server:

[![Discord](https://img.shields.io/discord/143316585233252352.svg?style=for-the-badge&label=Discord%20Chat&colorB=7289da)](https://discord.gg/0ndGBjvogdY5SnIw)
